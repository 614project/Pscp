﻿PSCP SDK installed files

- pscp.exe: CLI and SDK entrypoint (NativeAot)
- Pscp.LanguageServer.exe: language server used by pscp lsp (NativeAot)
- uninstall.exe: generated during installation
